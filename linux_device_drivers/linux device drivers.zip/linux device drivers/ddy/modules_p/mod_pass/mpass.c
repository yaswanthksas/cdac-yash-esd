#include<linux/init.h>      
#include<linux/module.h>            //headers
#include<linux/kernel.h>

MODULE_LICENSE("GPL");              //macros 
MODULE_AUTHOR("CDAC");

// static char* cvar = "cdac hyderabad";
static int a = 12;
// module_param(cvar,charp,S_IRUGO);  for command line arguments 
module_param(a,int,S_IRUGO);

static int __init mp_init(void){
    printk("In kernel\n");
    // printk("string : %s",cvar); 
    return 0;                             //functions - modules 
}
static void __exit mp_exit(void){
    printk("Bye kernal\n");
    printk("integer is : %d",a);
}

module_init(mp_init);
module_exit(mp_exit);